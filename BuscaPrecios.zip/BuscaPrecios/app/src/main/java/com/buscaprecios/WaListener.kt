package com.buscaprecios

import android.app.Notification
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class WaListener : NotificationListenerService() {
    private val summary = Regex("^\\d+ (mensajes|messages|new messages)", RegexOption.IGNORE_CASE)

    @Suppress("DEPRECATION")
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != "com.whatsapp" && sbn.packageName != "com.whatsapp.w4b") return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val e = n.extras
        val chat = (e.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)
            ?: e.getCharSequence(Notification.EXTRA_TITLE))?.toString() ?: return

        val list = ArrayList<Msg>()
        val arr = e.getParcelableArray(Notification.EXTRA_MESSAGES)
        if (arr != null) {
            for (p in arr) {
                val b = p as? Bundle ?: continue
                val t = b.getCharSequence("text")?.toString() ?: continue
                val s = b.getCharSequence("sender")?.toString() ?: ""
                list.add(Msg(chat, s, t, b.getLong("time", n.`when`)))
            }
        }
        if (list.isEmpty()) {
            val t = e.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
            list.add(Msg(chat, "", t, n.`when`))
        }
        val clean = list.filter { it.text.isNotBlank() && !summary.containsMatchIn(it.text) }
        if (clean.isEmpty()) return
        val db = Db(this)
        try { db.addAll(clean) } finally { db.close() }
    }
}
