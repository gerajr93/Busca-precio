package com.buscaprecios

import java.util.Calendar

data class Hit(
    val chat: String, val ts: Long, val line: String,
    val amount: Double?, val cur: String?, val cup: Double?, val guessed: Boolean
)

data class P(val amount: Double, val cur: String, val guessed: Boolean, val start: Int)

object Finder {
    private const val NUM = """(\d{1,3}(?:[.,]\d{3})+|\d+(?:[.,]\d+)?)"""
    private const val CUR = """(cup|mn|usd|dolares|dolar|pesos|peso|\$)"""
    private val POST = Regex("$NUM\\s*$CUR(?![a-z])")
    private val PRE = Regex("(?<![a-z])$CUR\\s*$NUM")
    private val THOUSANDS = Regex("\\d{1,3}([.,]\\d{3})+")

    private fun parse(s: String): Double? =
        if (THOUSANDS.matches(s)) s.replace(Regex("[.,]"), "").toDoubleOrNull()
        else s.replace(',', '.').toDoubleOrNull()

    fun prices(nl: String): List<P> {
        val out = ArrayList<P>()
        val used = ArrayList<IntRange>()
        fun add(m: MatchResult, numG: Int, curG: Int) {
            val a = parse(m.groupValues[numG]) ?: return
            val c = m.groupValues[curG]
            var cur = "CUP"
            var guessed = false
            when (c) {
                "usd", "dolar", "dolares" -> cur = "USD"
                "$" -> { guessed = true; cur = if (a <= 150) "USD" else "CUP" }
            }
            used.add(m.range)
            out.add(P(a, cur, guessed, m.range.first))
        }
        for (m in POST.findAll(nl)) add(m, 1, 2)
        for (m in PRE.findAll(nl)) {
            if (used.none { it.first <= m.range.last && m.range.first <= it.last }) add(m, 2, 1)
        }
        return out.sortedBy { it.start }
    }

    fun run(db: Db, term: String, rate: Double): List<Hit> {
        val words = norm(term).split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (words.isEmpty()) return emptyList()
        val hits = ArrayList<Hit>()
        for (m in db.search(words)) {
            for (line in m.text.split('\n')) {
                val nl = norm(line)
                if (!words.all { nl.contains(it) }) continue
                val idx = nl.indexOf(words[0])
                val ps = prices(nl)
                val p = ps.firstOrNull { it.start >= idx } ?: ps.firstOrNull()
                if (p != null) {
                    val cup = if (p.cur == "USD") p.amount * rate else p.amount
                    hits.add(Hit(m.chat, m.ts, line.trim(), p.amount, p.cur, cup, p.guessed))
                } else {
                    hits.add(Hit(m.chat, m.ts, line.trim(), null, null, null, false))
                }
            }
        }
        return hits.sortedByDescending { it.ts }
            .distinctBy { it.chat + "|" + norm(it.line) }
            .sortedWith(compareBy<Hit>({ it.cup == null }, { it.cup ?: 0.0 }))
    }

    // ---- Importar chat exportado de WhatsApp (.txt) ----
    private val START = Regex("^\\[?\\d{1,2}/\\d{1,2}/\\d{2,4},?\\s+\\d{1,2}:\\d{2}")
    private val LINE = Regex(
        "^\\[?(\\d{1,2})/(\\d{1,2})/(\\d{2,4}),?\\s+(\\d{1,2}):(\\d{2})(?::\\d{2})?(?:\\s*([ap])\\.?\\s?m\\.?)?\\]?\\s*[-–]?\\s*([^:]{1,60}?):\\s(.*)$",
        RegexOption.IGNORE_CASE
    )

    fun parseExport(chat: String, text: String): List<Msg> {
        val out = ArrayList<Msg>()
        var sender = ""
        var ts = 0L
        var sb: StringBuilder? = null
        fun flush() {
            val b = sb
            if (b != null && b.isNotBlank()) out.add(Msg(chat, sender, b.toString().trim(), ts))
            sb = null
        }
        for (raw in text.lineSequence()) {
            val line = raw.replace("\u200E", "").replace("\u202F", " ")
            if (START.containsMatchIn(line)) {
                flush()
                val m = LINE.find(line) ?: continue
                val g = m.groupValues
                var h = g[4].toInt()
                val ap = g[6].lowercase()
                if (ap == "p" && h < 12) h += 12
                if (ap == "a" && h == 12) h = 0
                var y = g[3].toInt()
                if (y < 100) y += 2000
                val cal = Calendar.getInstance()
                cal.clear()
                cal.set(y, g[2].toInt() - 1, g[1].toInt(), h, g[5].toInt())
                ts = cal.timeInMillis
                sender = g[7]
                sb = StringBuilder(g[8])
            } else {
                sb?.append('\n')?.append(line)
            }
        }
        flush()
        return out
    }
}
