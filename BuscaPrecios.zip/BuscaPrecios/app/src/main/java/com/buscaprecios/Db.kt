package com.buscaprecios

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.Normalizer

fun norm(s: String): String =
    Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")

data class Msg(val chat: String, val sender: String, val text: String, val ts: Long)

class Db(c: Context) : SQLiteOpenHelper(c.applicationContext, "msgs.db", null, 1) {
    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL(
            "CREATE TABLE msg(id INTEGER PRIMARY KEY, chat TEXT, sender TEXT, text TEXT, n TEXT, ts INTEGER, UNIQUE(chat,text,ts))"
        )
    }

    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}

    fun addAll(list: List<Msg>): Int {
        val d = writableDatabase
        var added = 0
        d.beginTransaction()
        try {
            for (m in list) {
                val v = ContentValues()
                v.put("chat", m.chat)
                v.put("sender", m.sender)
                v.put("text", m.text)
                v.put("n", norm(m.text))
                v.put("ts", m.ts)
                if (d.insertWithOnConflict("msg", null, v, SQLiteDatabase.CONFLICT_IGNORE) != -1L) added++
            }
            d.setTransactionSuccessful()
        } finally {
            d.endTransaction()
        }
        return added
    }

    fun count(): Int {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM msg", null).use {
            it.moveToFirst(); return it.getInt(0)
        }
    }

    fun search(words: List<String>): List<Msg> {
        val where = words.joinToString(" AND ") { "n LIKE ?" }
        val args = words.map { "%$it%" }.toTypedArray()
        val out = ArrayList<Msg>()
        readableDatabase.rawQuery(
            "SELECT chat,sender,text,ts FROM msg WHERE $where ORDER BY ts DESC LIMIT 3000", args
        ).use { c ->
            while (c.moveToNext()) out.add(Msg(c.getString(0), c.getString(1) ?: "", c.getString(2), c.getLong(3)))
        }
        return out
    }

    fun clear() {
        writableDatabase.execSQL("DELETE FROM msg")
    }
}
