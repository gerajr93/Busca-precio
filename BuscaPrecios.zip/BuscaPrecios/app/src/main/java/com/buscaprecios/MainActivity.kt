package com.buscaprecios

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val BG = 0xFF0B1220.toInt()
    private val CARD = 0xFF151F33.toInt()
    private val MUTED = 0xFF94A3B8.toInt()
    private val GREEN = 0xFF22C55E.toInt()

    private lateinit var db: Db
    private lateinit var root: LinearLayout
    private lateinit var results: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var dot: View
    private lateinit var query: EditText
    private lateinit var rateField: EditText

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(c: Int, r: Int, oval: Boolean = false) = GradientDrawable().apply {
        setColor(c)
        if (oval) shape = GradientDrawable.OVAL else cornerRadius = dp(r).toFloat()
    }

    private fun add(parent: LinearLayout, v: View, top: Int = 0) {
        parent.addView(v, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(top) })
    }

    private fun label(t: String) = TextView(this).apply {
        text = t; setTextColor(MUTED); textSize = 12f; letterSpacing = 0.1f
        typeface = Typeface.DEFAULT_BOLD
    }

    private fun btn(t: String, color: Int, txt: Int, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(txt); stateListAnimator = null; minHeight = dp(50)
        background = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), shape(color, 14), null)
        setOnClickListener { f() }
    }

    private fun field(h: String, type: Int = InputType.TYPE_CLASS_TEXT) = EditText(this).apply {
        hint = h; setTextColor(Color.WHITE); setHintTextColor(MUTED)
        inputType = type; setSingleLine(true)
        background = shape(CARD, 12)
        setPadding(dp(16), dp(14), dp(16), dp(14))
    }

    private fun pill(t: String, bg: Int, fg: Int) = TextView(this).apply {
        text = t; setTextColor(fg); textSize = 11f; typeface = Typeface.DEFAULT_BOLD
        background = shape(bg, 20)
        setPadding(dp(10), dp(4), dp(10), dp(4))
        setSingleLine(true); ellipsize = TextUtils.TruncateAt.END
    }

    private fun fmt(v: Double): String =
        if (v == Math.floor(v)) String.format(Locale.US, "%,.0f", v) else String.format(Locale.US, "%,.2f", v)

    private fun ago(ts: Long): String {
        val d = (System.currentTimeMillis() - ts) / 86_400_000L
        return when {
            d <= 0 -> "hoy"
            d == 1L -> "ayer"
            else -> "hace $d d"
        }
    }

    private fun refreshStatus() {
        val on = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        val n = db.count()
        statusText.text = if (on) "Escuchando WhatsApp · $n mensajes guardados"
        else "Toca aquí y activa el acceso a notificaciones ($n mensajes guardados)"
        dot.background = shape(if (on) GREEN else 0xFFEF4444.toInt(), 0, true)
    }

    override fun onResume() { super.onResume(); refreshStatus() }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    @Suppress("DEPRECATION")
    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val u = i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            if (u != null) importChat(u) else toast("No llegó ningún archivo")
        }
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun displayName(u: Uri): String? = try {
        contentResolver.query(u, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
        }
    } catch (e: Exception) { null }

    private fun importChat(uri: Uri) {
        val name = displayName(uri) ?: "WhatsApp"
        if (name.endsWith(".zip", true)) { toast("Exporta el chat SIN archivos multimedia (.txt)"); return }
        val chat = name.removeSuffix(".txt").removePrefix("Chat de WhatsApp con ")
            .removePrefix("WhatsApp Chat with ").trim()
        toast("Importando…")
        thread {
            val text = try { contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: "" } catch (e: Exception) { "" }
            val added = db.addAll(Finder.parseExport(chat, text))
            runOnUiThread { toast("$added mensajes nuevos de $chat"); refreshStatus() }
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 7 && res == RESULT_OK) data?.data?.let { importChat(it) }
    }

    private fun search() {
        val rate = rateField.text.toString().replace(',', '.').toDoubleOrNull() ?: 0.0
        if (rate <= 0) { toast("Primero pon la tasa: 1 USD = ? CUP"); return }
        getSharedPreferences("cfg", MODE_PRIVATE).edit().putString("rate", rateField.text.toString()).apply()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(query.windowToken, 0)
        val terms = query.text.toString().split(",").map { it.trim() }.filter { it.isNotEmpty() }
        results.removeAllViews()
        if (terms.isEmpty()) return
        thread {
            val all = terms.map { it to Finder.run(db, it, rate) }
            runOnUiThread { render(all, rate) }
        }
    }

    private fun render(all: List<Pair<String, List<Hit>>>, rate: Double) {
        results.removeAllViews()
        for ((term, hits) in all) {
            add(results, label("${term.uppercase()} · ${hits.size} resultado(s)"), 22)
            if (hits.isEmpty()) {
                add(results, TextView(this).apply {
                    text = "Sin resultados. Importa más chats o espera nuevos mensajes."
                    setTextColor(MUTED); textSize = 14f
                }, 8)
            }
            hits.take(100).forEachIndexed { i, h -> add(results, card(h, i == 0 && h.cup != null, rate), 10) }
        }
    }

    private fun card(h: Hit, best: Boolean, rate: Double): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(CARD, 16)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val prices = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (h.cup != null && h.amount != null && h.cur != null) {
            prices.addView(TextView(this).apply {
                text = fmt(h.amount) + " " + h.cur + if (h.guessed) " ?" else ""
                setTextColor(Color.WHITE); textSize = 22f; typeface = Typeface.DEFAULT_BOLD
            })
            prices.addView(TextView(this).apply {
                text = if (h.cur == "USD") "≈ ${fmt(h.cup)} CUP" else "≈ ${fmt(h.cup / rate)} USD"
                setTextColor(MUTED); textSize = 13f
            })
        } else {
            prices.addView(TextView(this).apply {
                text = "Sin precio"; setTextColor(MUTED); textSize = 18f; typeface = Typeface.DEFAULT_BOLD
            })
        }
        top.addView(prices, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        if (best) top.addView(pill("MÁS BARATO", 0xFF14532D.toInt(), GREEN))
        box.addView(top)
        add(box, TextView(this).apply {
            text = h.line; setTextColor(0xFFE2E8F0.toInt()); textSize = 14f
        }, 10)
        val bottom = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        bottom.addView(pill(h.chat, 0xFF1E3A5F.toInt(), 0xFF93C5FD.toInt()), LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        bottom.addView(TextView(this).apply {
            text = ago(h.ts); setTextColor(MUTED); textSize = 12f
            setPadding(dp(10), 0, 0, 0)
        })
        add(box, bottom, 12)
        return box
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        db = Db(this)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = 0
        window.statusBarColor = BG
        window.navigationBarColor = BG

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(32))
        }
        add(root, TextView(this).apply {
            text = "Busca Precios"; setTextColor(Color.WHITE); textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
        })
        add(root, TextView(this).apply {
            text = "Lo más barato en tus grupos y canales de WhatsApp"
            setTextColor(MUTED); textSize = 14f
        }, 4)

        dot = View(this)
        statusText = TextView(this).apply { setTextColor(Color.WHITE); textSize = 13f }
        val status = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = shape(CARD, 14)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            addView(dot, LinearLayout.LayoutParams(dp(10), dp(10)).apply { rightMargin = dp(12) })
            addView(statusText, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }
        add(root, status, 20)

        add(root, label("PRODUCTOS (separa con comas)"), 24)
        query = field("pollo, aceite, arroz").apply {
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setOnEditorActionListener { _, id, _ ->
                if (id == EditorInfo.IME_ACTION_SEARCH) { search(); true } else false
            }
        }
        add(root, query, 8)

        add(root, label("TASA DE CAMBIO"), 18)
        val rateRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        rateRow.addView(TextView(this).apply { text = "1 USD ="; setTextColor(Color.WHITE); textSize = 15f })
        rateField = field("CUP", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL).apply {
            setText(getSharedPreferences("cfg", MODE_PRIVATE).getString("rate", ""))
        }
        rateRow.addView(rateField, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { leftMargin = dp(12); rightMargin = dp(12) })
        rateRow.addView(TextView(this).apply { text = "CUP"; setTextColor(Color.WHITE); textSize = 15f })
        add(root, rateRow, 8)

        add(root, btn("Buscar", GREEN, 0xFF052E16.toInt()) { search() }, 18)

        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        add(root, results, 0)

        add(root, label("AJUSTES"), 32)
        add(root, btn("Importar chat exportado (.txt)", CARD, Color.WHITE) {
            @Suppress("DEPRECATION")
            startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }, 7
            )
        }, 8)
        add(root, btn("Batería sin restricciones", CARD, Color.WHITE) {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        }, 8)
        add(root, btn("Borrar historial", CARD, 0xFFFCA5A5.toInt()) {
            AlertDialog.Builder(this).setTitle("¿Borrar todos los mensajes guardados?")
                .setPositiveButton("Borrar") { _, _ -> db.clear(); results.removeAllViews(); refreshStatus() }
                .setNegativeButton("Cancelar", null).show()
        }, 8)
        add(root, TextView(this).apply {
            text = "Para traer mensajes viejos: en WhatsApp abre el grupo > ⋮ > Más > Exportar chat > Sin archivos > elige Busca Precios."
            setTextColor(MUTED); textSize = 12f
        }, 14)

        setContentView(ScrollView(this).apply { setBackgroundColor(BG); addView(root) })
        handleIntent(intent)
    }
}
